package vce.in.tests;

import java.util.ArrayList;

import vce.in.core.Polynomial;

//import vce.in.core;

public class TestPolynomial {
	
		public static void main(String[] args) {
			
			ArrayList<Polynomial> arrayList=new ArrayList<Polynomial>();
			// TODO Auto-generated method stub
			Polynomial p1 = new Polynomial();
			Polynomial p2 = new Polynomial();
			PolynomialGUI tcgui = new PolynomialGUI(p1,p2,arrayList);

		}

	}



