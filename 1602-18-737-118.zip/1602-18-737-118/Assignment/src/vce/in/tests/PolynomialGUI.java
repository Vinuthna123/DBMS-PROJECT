package vce.in.tests;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.swing.*;

import vce.in.core.Polynomial;
import vce.in.excepts.WrongInputException;

import java.util.*;

public class PolynomialGUI extends JFrame {
	
	private JMenuBar mBar;
	private JMenu mnuFile;
	private JMenu mnuHelp;
	private JMenuItem miSave;
	private JMenuItem miExit;
	private JMenuItem miAbtThisAss;
	private JMenuItem miCredits;
	private JLabel lblPoly1;
	private JLabel lblPoly2;
	private JTextField txtPoly1;
	private JTextField txtPoly2;
	private JButton Finish;
	private JLabel lblPoly3;
	private JLabel lblPoly4;
	private JLabel lblPoly5;
	private JTextField txtPoly3;
	private JTextField txtPoly4;
	private JTextField txtPoly5;
	private JFrame j;
	private JPanel l1;
	private JPanel l2;
	private Polynomial p1;
	private Polynomial p2;
	ArrayList<Polynomial> arrayList;
	
	public PolynomialGUI(Polynomial p1,Polynomial p2,ArrayList<Polynomial> arrayList)
	{
		this.p1=p1;
		this.p2=p2;
		this.arrayList = arrayList;
		mBar = new JMenuBar();
		mnuFile = new JMenu("File");
		mnuHelp=new JMenu("Help");
		miSave = new JMenuItem("Save");
		miExit = new JMenuItem("exit");
		miAbtThisAss = new JMenuItem("About this Assignment");
		miCredits = new JMenuItem("Credits");
		lblPoly1 = new JLabel("1st Polynomial");
		lblPoly2 = new JLabel("2nd Polynomial");
		txtPoly1 = new JTextField(10);
		txtPoly2 = new JTextField(10);
		Finish = new JButton("Finish");
		lblPoly3 = new JLabel("Addition :");
		lblPoly4 = new JLabel("Subtraction :");
		lblPoly5 = new JLabel("Multiplication :");
		txtPoly3 = new JTextField(25);
		txtPoly4 = new JTextField(25);
		txtPoly5 = new JTextField(25);
		l1 = new JPanel();
		l2 = new JPanel();
		
		l1.setPreferredSize(new Dimension(150, 200));
		l1.setBackground(Color.white);
		l2.setBackground(Color.white);
		l2.setPreferredSize(new Dimension(400, 200));
		add(l1);
		add(l2);
		mnuFile.add(miSave);
		mnuFile.add(miExit);
		mnuHelp.add(miAbtThisAss);
		mnuHelp.add(miCredits);
		mBar.add(mnuFile);
		mBar.add(mnuHelp);
		setLayout(new FlowLayout());
		setJMenuBar(mBar);
		l1.add(lblPoly1);
		l1.add(txtPoly1);
		l1.add(lblPoly2);
		l1.add(txtPoly2);
		l1.add(Finish);
		l2.add(lblPoly3);
		l2.add(txtPoly3);
		l2.add(lblPoly4);
		l2.add(txtPoly4);
		l2.add(lblPoly5);
		l2.add(txtPoly5);

		pack();
		setVisible(true);
		
		txtPoly1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae) 
			{
				String s=" ";
				int i=0;
				s = txtPoly1.getText();
				StringTokenizer st = new StringTokenizer(s,",");
				double arr1[]=new double[st.countTokens()];
				while(st.hasMoreTokens())
				{
					String s1 = st.nextToken();
					Double d=Double.parseDouble(s1);
					arr1[i++]=d;
				}
				PolynomialGUI.this.p1.setCoeff(arr1);
				arrayList.add(p1);
			}
		
		});
		
		txtPoly2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae) {
				
				int i=0;
				String s = txtPoly2.getText();
				StringTokenizer st = new StringTokenizer(s,",");
				double arr2[]=new double[st.countTokens()];
				while(st.hasMoreTokens())
				{
					String s1 = st.nextToken();
					Double d=Double.parseDouble(s1);
					arr2[i++]=d;
				}
				PolynomialGUI.this.p2.setCoeff(arr2);
				arrayList.add(p2);
			}
		});
		
		Finish.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae) {
				
				txtPoly3.setText((PolynomialGUI.this.arrayList.get(0).add(PolynomialGUI.this.arrayList.get(1)))+" ");
				txtPoly4.setText((PolynomialGUI.this.arrayList.get(0).minus(PolynomialGUI.this.arrayList.get(1))) + " ");
				txtPoly5.setText((PolynomialGUI.this.arrayList.get(0).multiply(PolynomialGUI.this.arrayList.get(1)))+" ");
				
				}
		});
		
		miSave.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae) {
				
				try {
					FileOutputStream fos=new FileOutputStream(new File("data.bin"));
					ObjectOutputStream oos=new ObjectOutputStream (fos);
					oos.writeObject(p1);
					oos.writeObject(p2);
					oos.writeObject(txtPoly3.getText());
					oos.writeObject(txtPoly4.getText());
					oos.writeObject(txtPoly5.getText());
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			
		});
		
		miAbtThisAss.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae) {
				
				 JOptionPane.showMessageDialog(
				            null,
				            "INPUT : Enter the Coefficients of Polynomial 1 in the 1st text field separated by commas and the click 'enter'."
				            + "Move the cursor to the 2nd text field \nand enter coefficients for 2nd polynomial "+
				            "again press 'enter'.\n If u do not want a term in the polynomial enter '0' in place of it. For example: "
				            + "if u want your polynomial to look like :"+"3x^3 + 4x^1 then enter coefficients in this format: 3,0,4,0\n"
				            +"OUTPUT : After clicking FINISH button we can see the  three polynomials  "
				            +"in addition,subtraction and multiplication text fields ",
				            "About This Assignment",
				            JOptionPane.PLAIN_MESSAGE);
			}
		});
		
		miCredits.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae) {
				
				JOptionPane.showMessageDialog(null,"ROLL NO : 1602-18-737-118\n"+"NAME : Vinuthna Tatikonda","Credits",JOptionPane.PLAIN_MESSAGE);
			}
			
		});
		
		miExit.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae) {
				System.exit(0);
			}
			
		});
		
		
		
	}
}
