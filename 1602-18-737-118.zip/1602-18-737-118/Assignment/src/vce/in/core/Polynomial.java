package vce.in.core;
import java.io.*;
 public class Polynomial implements Serializable
{
	private double coefficients[];//atrribute coefficient is an array of double values
	public Polynomial(double[] coefficients)//parameterized constructor
	{
		this.coefficients=coefficients;
	}
	public Polynomial()
	{
		
	}
	//getter setter methods
	public void setCoeff(double[] coefficients)
	{
		this.coefficients=coefficients;
	}
	public double[] getCoeff()
	{
		return coefficients;
	}
	//Polynomial Addition
	public Polynomial add(Polynomial poly2)
	{
	//considering length of array1 in this polynomial greater than array2 in poly2
		int n2=coefficients.length;
		int n1=poly2.coefficients.length;
		double[] coeff1=new double[n2];//sum array whose length does not exceed length of larger array
		for(int i=0;i<(n2-n1);i++)
		{
		coeff1[i]=coefficients[i];//directly coying array1 elements into sum array
		}
		int j=0;
		for(int i=n2-n1;i<n2;i++)
		{
			coeff1[i]=coefficients[i]+poly2.coefficients[j];//left over elements in array1 and elements in array2 are added
			j=j+1;
		}
	   	Polynomial poly3=new Polynomial(coeff1);
		poly3.coefficients=coeff1;
		return poly3;
	}
	public Polynomial minus(Polynomial poly2)
	{
		int n2=coefficients.length;
		int n1=poly2.coefficients.length;
		double[] coeff1=new double[n2];
		for(int i=0;i<(n2-n1);i++)
		{
			coeff1[i]=coefficients[i];
		}
		int j=0;
		for(int i=n2-n1;i<n2;i++)
		{
			coeff1[i]=coefficients[i]-poly2.coefficients[j];/*process is same as addition but the left over elements in array1 
			and elements in array2 are subtracted*/
			j=j+1;
		}
		Polynomial poly3=new Polynomial(coeff1);
		poly3.coefficients=coeff1;
		return poly3;
	}
	
	public Polynomial multiply(Polynomial poly2)
	{
		int n2=coefficients.length - 1;
		int n1=poly2.coefficients.length - 1;
		int n3=coefficients.length*poly2.coefficients.length;
		int[] pow=new int[n3];//array for all the exponents
		double[] n=new double[n3];//array for all the coefficients
		int k=0,l=0,p=0,count=0,z=0;
		for(int i=0;i<=n2;i++)
		{
			for(int j=0;j<=n1;j++)
			{
			n[k++]=coefficients[i]*poly2.coefficients[j];/*separating exponents and coefficients(obtained after 								multiplication)into two arrays */
			pow[l++]=(n1-i)+(n2-j);
			}
		}
		double[] coeff1=new double[n3];//multiplication array
	    	double sum;
		for(int i=0;i<n3;i++)
		{
			sum=n[i];
			for(int j=i+1;j<n3;j++)
			{
				if((n[j]!=-1)&&(pow[i]==pow[j]))
				{
				sum=sum+n[j];//elements having same exponents are added
				n[j]=-1;//the element which is added is made -1 
				}
		    	}
			coeff1[p++]=sum;//resultant sum is appended to the multiplication array
		}
	    	
		for(int i=0;i<n3;i++)
		{
			if((coeff1[i]!=-1)&&(coeff1[i]!=0.0))
			count++;	
		}
		double[] arr3=new double[count];
		for(int i=0;i<n3;i++)
	    	{
			if((coeff1[i]!=-1)&&(coeff1[i]!=0.0))
			arr3[z++]=coeff1[i];
		}
		Polynomial poly3=new Polynomial(arr3);
		poly3.coefficients=arr3;
		return poly3;
	}
	public String Expression()
	{
		//here coefficient array is converted into polynomial
		int n=getCoeff().length -1;
		String sum="";
		for(int i=n;i>=0;i--)
		{
			if(getCoeff()[n-i]==0)
			continue;
			if(i!=n)
			{
				if(getCoeff()[n-i]  < 0)
				sum=sum+((getCoeff()[n-i])+"x^"+i);
				else
				sum=sum+("+"+(getCoeff()[n-i])+"x^"+i);
			}
			if(i==n)
			sum=sum+(getCoeff()[n-i]+"x^"+i);
		}
		return sum;
	    	
	}
	public String toString()
	{
		return Expression();
	}
	
}