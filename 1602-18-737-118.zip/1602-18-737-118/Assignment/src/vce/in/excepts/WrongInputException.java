package vce.in.excepts;
public class WrongInputException extends Exception
{
	public WrongInputException()
	{
		
	}
	public String toString()
	{
		return "You have given a wrong input";
	}
}


